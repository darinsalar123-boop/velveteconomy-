# VelvetEconomy

A starter economy plugin for Paper 1.21.4 servers.

## Included commands

- `/bal` or `/balance` — check your balance
- `/bal <player>` — check another player's balance (requires `velveteconomy.balance.others`)
- `/pay <player> <amount>` — pay an online player
- `/baltop` — show the 10 highest saved balances
- `/money give <player> <amount>` — admin: add money
- `/money set <player> <amount>` — admin: set balance
- `/money remove <player> <amount>` — admin: remove money

New accounts start with **$500.00**. Balances are stored in `plugins/VelvetEconomy/config.yml` and saved when transactions happen and when the server stops.

## Build the plugin

This project requires Java 21 and Maven.

From the project root, run:

```bash
mvn package
```

The compiled plugin will be at:

```text
target/VelvetEconomy.jar
```

Upload that JAR to your Paper server's `plugins` folder and restart the server.

## Important notes

- This is a starter economy plugin, not a complete Donut SMP clone.
- `/pay` currently requires the recipient to be online.
- `/baltop` lists accounts that have been recorded by this plugin.
- It does not yet include a GUI shop, auction house, player trading, crates, or Geyser configuration.
- Geyser/Floodgate are separate server plugins; this economy plugin works on Paper and can be used by Java and Bedrock players connected through Geyser.
- Test on a backup or private server before using it on a live world.
