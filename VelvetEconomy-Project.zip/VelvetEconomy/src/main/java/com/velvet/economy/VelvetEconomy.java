package com.velvet.economy;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;
import java.util.stream.Collectors;

public final class VelvetEconomy extends JavaPlugin {
    private final Map<UUID, BigDecimal> balances = new HashMap<>();
    private final Map<UUID, String> playerNames = new HashMap<>();
    private final BigDecimal startingBalance = new BigDecimal("500.00");

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadBalances();

        for (Player player : Bukkit.getOnlinePlayers()) {
            ensureAccount(player);
        }

        getLogger().info("VelvetEconomy enabled.");
    }

    @Override
    public void onDisable() {
        saveBalances();
    }

    private void loadBalances() {
        balances.clear();
        playerNames.clear();

        var section = getConfig().getConfigurationSection("accounts");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                String amount = getConfig().getString("accounts." + key + ".balance", "500.00");
                String name = getConfig().getString("accounts." + key + ".name", "Unknown");
                balances.put(uuid, new BigDecimal(amount));
                playerNames.put(uuid, name);
            } catch (IllegalArgumentException ex) {
                getLogger().warning("Skipped invalid account entry: " + key);
            }
        }
    }

    private void saveBalances() {
        getConfig().set("accounts", null);
        for (UUID uuid : balances.keySet()) {
            String path = "accounts." + uuid;
            getConfig().set(path + ".balance", format(balances.get(uuid)));
            getConfig().set(path + ".name", playerNames.getOrDefault(uuid, "Unknown"));
        }
        saveConfig();
    }

    private void ensureAccount(OfflinePlayer player) {
        balances.putIfAbsent(player.getUniqueId(), startingBalance);
        if (player.getName() != null) {
            playerNames.put(player.getUniqueId(), player.getName());
        }
    }

    private BigDecimal balance(UUID uuid) {
        return balances.getOrDefault(uuid, startingBalance);
    }

    private String format(BigDecimal amount) {
        return amount.setScale(2, RoundingMode.HALF_UP).toPlainString();
    }

    private BigDecimal parseAmount(String input) {
        try {
            BigDecimal amount = new BigDecimal(input).setScale(2, RoundingMode.HALF_UP);
            if (amount.compareTo(BigDecimal.ZERO) <= 0 || amount.scale() > 2) return null;
            return amount;
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private void reply(CommandSender sender, String message) {
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&', "&b&lVELVET &8» &f" + message));
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        switch (command.getName().toLowerCase(Locale.ROOT)) {
            case "bal" -> {
                if (args.length == 0) {
                    if (!(sender instanceof Player player)) {
                        reply(sender, "Console must use &e/bal <player>&f.");
                        return true;
                    }
                    ensureAccount(player);
                    reply(sender, "Your balance: &a$" + format(balance(player.getUniqueId())));
                    return true;
                }
                if (!sender.hasPermission("velveteconomy.balance.others")) {
                    reply(sender, "&cYou cannot check other players' balances.");
                    return true;
                }
                OfflinePlayer target = findPlayer(args[0]);
                if (target == null) {
                    reply(sender, "&cPlayer not found.");
                    return true;
                }
                ensureAccount(target);
                reply(sender, target.getName() + "'s balance: &a$" + format(balance(target.getUniqueId())));
                return true;
            }
            case "pay" -> {
                if (!(sender instanceof Player player)) {
                    reply(sender, "Only players can use this command.");
                    return true;
                }
                if (args.length != 2) {
                    reply(sender, "Usage: &e/pay <player> <amount>");
                    return true;
                }
                Player target = Bukkit.getPlayerExact(args[0]);
                BigDecimal amount = parseAmount(args[1]);
                if (target == null) {
                    reply(sender, "&cThat player must be online.");
                    return true;
                }
                if (target.getUniqueId().equals(player.getUniqueId())) {
                    reply(sender, "&cYou cannot pay yourself.");
                    return true;
                }
                if (amount == null) {
                    reply(sender, "&cEnter a valid amount greater than 0 (maximum 2 decimals).");
                    return true;
                }
                ensureAccount(player);
                ensureAccount(target);
                if (balance(player.getUniqueId()).compareTo(amount) < 0) {
                    reply(sender, "&cYou don't have enough money.");
                    return true;
                }

                balances.put(player.getUniqueId(), balance(player.getUniqueId()).subtract(amount));
                balances.put(target.getUniqueId(), balance(target.getUniqueId()).add(amount));
                reply(player, "You paid &a$" + format(amount) + " &fto &b" + target.getName() + "&f.");
                reply(target, "You received &a$" + format(amount) + " &ffrom &b" + player.getName() + "&f.");
                saveBalances();
                return true;
            }
            case "baltop" -> {
                List<Map.Entry<UUID, BigDecimal>> top = balances.entrySet().stream()
                        .sorted(Map.Entry.<UUID, BigDecimal>comparingByValue().reversed())
                        .limit(10)
                        .collect(Collectors.toList());
                reply(sender, "&b&lTOP BALANCES");
                if (top.isEmpty()) {
                    reply(sender, "No balances have been recorded yet.");
                    return true;
                }
                int rank = 1;
                for (var entry : top) {
                    String name = playerNames.getOrDefault(entry.getKey(), "Unknown");
                    sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                            "&7#" + rank++ + " &f" + name + " &8- &a$" + format(entry.getValue())));
                }
                return true;
            }
            case "money" -> {
                if (!sender.hasPermission("velveteconomy.admin")) {
                    reply(sender, "&cYou don't have permission.");
                    return true;
                }
                if (args.length != 3) {
                    reply(sender, "Usage: &e/money <give|set|remove> <player> <amount>");
                    return true;
                }
                OfflinePlayer target = findPlayer(args[1]);
                BigDecimal amount = parseAmount(args[2]);
                if (target == null || amount == null) {
                    reply(sender, "&cUse a known player and a valid positive amount.");
                    return true;
                }
                ensureAccount(target);
                BigDecimal current = balance(target.getUniqueId());
                BigDecimal updated;
                switch (args[0].toLowerCase(Locale.ROOT)) {
                    case "give" -> updated = current.add(amount);
                    case "set" -> updated = amount;
                    case "remove" -> {
                        if (current.compareTo(amount) < 0) {
                            reply(sender, "&cThat player doesn't have enough money.");
                            return true;
                        }
                        updated = current.subtract(amount);
                    }
                    default -> {
                        reply(sender, "&cUse give, set, or remove.");
                        return true;
                    }
                }
                balances.put(target.getUniqueId(), updated);
                saveBalances();
                reply(sender, "Updated " + target.getName() + "'s balance to &a$" + format(updated));
                if (target.isOnline()) {
                    reply(target.getPlayer(), "Your balance is now &a$" + format(updated));
                }
                return true;
            }
            default -> {
                return false;
            }
        }
    }

    private OfflinePlayer findPlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online;

        for (UUID uuid : playerNames.keySet()) {
            if (playerNames.get(uuid).equalsIgnoreCase(name)) {
                return Bukkit.getOfflinePlayer(uuid);
            }
        }

        OfflinePlayer cached = Bukkit.getOfflinePlayerIfCached(name);
        return cached;
    }
}
